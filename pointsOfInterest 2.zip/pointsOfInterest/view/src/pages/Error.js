import { Link } from "react-router-dom";
// import img from "../assets/images/not-found.svg";
import styled from "styled-components";

const Wrapper = styled.div`
  .error-heading {
    text-align: center;
    font-size: 100px;
    color: red;
  }

  .error-msg {
    text-align: center;
    font-size: 60px;
    font-weight: 700;
  }
`;

const Error = () => {
  return (
    <Wrapper>
      <h1 className="error-heading"> Error ❗️</h1>
      <p className="error-msg">Page not found...</p>
    </Wrapper>
  );
};

export default Error;
