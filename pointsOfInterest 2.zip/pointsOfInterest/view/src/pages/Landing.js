import React, { useState, useMemo } from "react";
import Map from "../components/Map";
import styled from "styled-components";
import { useAppContext } from "../context/appContext";
import Logo from "../assets/logo.png";
import { FaUserCircle, FaSignOutAlt, FaSearch } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

const Wrapper = styled.div`
  @import url(https://fonts.googleapis.com/css?family=Open+Sans);
  @import url(https://fonts.googleapis.com/css?family=Montserrat);
  html {
    font-family: "Lucida Sans", "Lucida Sans Regular", "Lucida Grande",
      "Lucida Sans Unicode", Geneva, Verdana, sans-serif;
    color: #222;
    font-size: 1em;
    line-height: 1.5;
    box-sizing: border-box;
  }

  body {
    background: #f2f2f2;
    font-family: "Open Sans", sans-serif;
    margin: 0;
  }

  /* Navbar starts  */

  a {
    color: #777;
    text-decoration: none;
  }

  /* Navbar ends */

  .main-section {
    margin-top: 0px;
  }

  .main-heading {
    width: 500px;
    margin: 30px auto;
    font-size: 50px;
    opacity: 0.8;
    text-align: center;
  }
  .search {
    width: 100%;
    position: relative;
    display: flex;
  }

  .searchTerm {
    width: 100%;
    border: 3px solid #00b4cc;
    border-right: none;
    padding: 5px;
    height: 20px;
    border-radius: 5px 0 0 5px;
    outline: none;
    color: #9dbfaf;
  }

  .searchTerm:focus {
    color: #00b4cc;
  }

  .searchButton {
    width: 40px;
    height: 36px;
    border: 1px solid #00b4cc;
    background: #00b4cc;
    text-align: center;
    color: #fff;
    border-radius: 0 5px 5px 0;
    cursor: pointer;
    font-size: 20px;
  }

  /*Resize the wrap to see the search bar change!*/
  .wrap {
    width: 30%;
    margin: 0 auto;
    /* position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%); */
  }

  .btn {
    appearance: none;
    -webkit-appearance: none;
    font-family: sans-serif;
    cursor: pointer;
    padding: 12px;
    min-width: 100px;
    border: 0px;
    -webkit-transition: background-color 100ms linear;
    -ms-transition: background-color 100ms linear;
    transition: background-color 100ms linear;
  }

  .btn:focus,
  .btn.focus {
    outline: 0;
  }

  .btn-round-2 {
    border-radius: 20px;
  }

  .btn-primary {
    background: #00b4cc;
    color: #ffffff;
  }

  .btn-primary:hover {
    background: #01a3b9;
    color: #ffffff;
  }

  #search-results-wrapper {
    width: 60%;
    margin: 30px auto;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
  }
  .search-results {
    border-top: 5px solid #00b4cc;
    width: 80%;
    text-align: center;
    background-color: white;
    padding: 20px;
  }
  .action {
    width: 150px;
  }
  .profile {
    position: relative;
    background-color: #00b4cc;
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 32px;
    text-align: center;
    border-radius: 10px;
    color: white;
    overflow: hidden;
    cursor: pointer;
  }

  /* .profile img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
  } */

  .dropdown-profile {
    position: absolute;
    top: 120px;
    /* padding: 10px 20px; */
    background: #fff;
    width: 150px;
    box-sizing: 0 5px 25px rgba(0, 0, 0, 0.1);
    border-radius: 15px;
    -webkit-transition: 0.5s;
    transition: 0.5s;
    visibility: hidden;
    opacity: 0;
  }

  .dropdown-profile.active {
    top: 80px;
    visibility: visible;
    opacity: 1;
  }

  .dropdown-profile::before {
    content: "";
    position: absolute;
    top: -5px;
    right: 28px;
    width: 20px;
    height: 20px;
    background: #fff;
    transform: rotate(45deg);
  }

  .dropdown-profile h3 {
    width: 100%;
    text-align: center;
    font-size: 18px;
    padding: 20px 0;
    font-weight: 500;
    color: #555;
    line-height: 1.5em;
  }

  .dropdown-profile h3 span {
    font-size: 14px;
    color: #cecece;
    font-weight: 300;
  }
  .dropdown-profile ul {
    padding-left: 0;
  }
  .dropdown-profile ul li {
    list-style: none;
    padding: 16px 0;
    border-top: 1px solid rgba(0, 0, 0, 0.05);
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .dropdown-profile ul li img {
    max-width: 20px;
    margin-right: 10px;
    opacity: 0.5;
    transition: 0.5s;
  }

  .dropdown-profile ul li:hover img {
    opacity: 1;
  }

  .dropdown-profile ul li a {
    display: inline-block;
    text-decoration: none;
    color: #555;
    font-weight: 500;
    transition: 0.5s;
  }

  .dropdown-profile ul li:hover a {
    color: #ff5d94;
  }

  .profile-name {
    background-color: #00b4cc;
    text-align: center;
    width: 100%;
    display: flex;
  }

  .navbar {
    display: flex;
    align-items: center;
    width: 100%;
    height: 90px;
  }

  .navbar .navbar-inner {
    display: flex;
    justify-content: space-between;
    flex-direction: row;
    width: 80%;
    margin: 0 auto;

    align-items: center;
  }

  .links-n-profile {
    justify-content: end;
  }

  .profile-icon {
    padding-top: 3px;
    transform: translate(0, 2px);
  }

  svg {
    margin-right: 5px;
  }
`;

const initialState = {
  isMember: true,
};

const Landing = () => {
  const [values, setValues] = useState(initialState);
  const [localSearch, setLocalSearch] = useState("");
  const { user, totalRows, rows, getSearchResults, logoutUser, handleChange } =
    useAppContext();

  // Map code

  const navigate = useNavigate();

  const toggleMember = () => {
    setValues({ ...values, isMember: !values.isMember });
  };

  // const handleSearch = (e) => {
  //   if (isLoading) return;
  //   handleChange({ name: e.target.name, value: e.target.value });
  // };
  // const handleChange = (e) => {
  //   e.preventDefault();
  //   setValues({ ...values, [e.target.name]: e.target.value });
  // };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("search");
    getSearchResults(localSearch);
  };

  const menuToggle = () => {
    const toggleMenu = document.querySelector(".dropdown-profile");
    toggleMenu.classList.toggle("active");
  };
  const debounce = () => {
    let timeoutID;
    return (e) => {
      setLocalSearch(e.target.value);
      clearTimeout(timeoutID);
      timeoutID = setTimeout(() => {
        handleChange({ name: e.target.name, value: e.target.value });
      }, 1000);
    };
  };
  // eslint-disable-next-line
  const optimizedDebounce = useMemo(() => debounce(), []);
  return (
    <Wrapper>
      <nav className="navbar">
        <div className="navbar-inner">
          <div className="logo">
            <a className="logo" href="/">
              <img src={Logo} alt="Points of interest" width="120" />
            </a>
          </div>
          <div className="links-n-profile">
            {user && user.length > 0 ? (
              //  Dropdown
              <div className="action">
                <div className="profile" onClick={menuToggle}>
                  {/* <!-- <img src="./assets/avatar.jpg" /> --> */}
                  <span id="profile-name">
                    <span>
                      <FaUserCircle className="profile-icon" size="15" />
                    </span>
                    <span>
                      {`${user.charAt(0).toUpperCase()}${user.slice(1)}`}
                    </span>
                  </span>
                </div>
                <div className="dropdown-profile">
                  <ul>
                    <li onClick={logoutUser}>
                      <FaSignOutAlt size="15" />
                      <a href="#">Logout</a>
                    </li>
                  </ul>
                </div>
              </div>
            ) : (
              //  dropdown ends
              <button
                onClick={() =>
                  setTimeout(() => {
                    navigate("/register");
                  }, 500)
                }
                className="btn btn-primary btn-round-2"
              >
                Login
              </button>
            )}
          </div>
        </div>
      </nav>

      <section className="main-section">
        <h1 className="main-heading">Points Of Interest</h1>
        <div className="wrap">
          <form action="#" onSubmit={handleSubmit}>
            <div className="search">
              <input
                id="searchTerm"
                name="search"
                type="text"
                value={localSearch}
                className="searchTerm"
                onChange={optimizedDebounce}
                placeholder="Search by region only !!"
              />
              <button type="submit" className="searchButton">
                <FaSearch size="15" />
              </button>
            </div>
          </form>
        </div>
        <div>
          <Map />
        </div>
        <div id="search-results-wrapper">
          {rows ? (
            rows.map((row) => {
              return (
                <div key={row.ID} className="search-results">
                  <h1>{row.name}</h1>
                  <p>
                    location: {row.region} {row.type}, {row.country}
                  </p>
                  <p>Description: {row.description}</p>
                  <p>Recommendations: {row.recommendations}</p>
                </div>
              );
            })
          ) : (
            <div className="search-results">
              <h3>No search results found with this keyword</h3>
            </div>
          )}
          {/* <div className="search-results">
            <h3 className="search-results-name">Sanfrancisco</h3>
            <p className="search-results-location">
              location: California City, USA
            </p>
            <p className="search-results-description">
              Description: Beautiful City with big tech companies.
            </p>
            <p>Recommendations: 0</p>
          </div> */}
        </div>
      </section>
    </Wrapper>
  );
};

export default Landing;
