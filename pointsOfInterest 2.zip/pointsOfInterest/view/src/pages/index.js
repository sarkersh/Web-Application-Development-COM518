import Landing from "./Landing";
import Register from "./Register";
import Error from "./Error";
export { Landing, Register, Error };
