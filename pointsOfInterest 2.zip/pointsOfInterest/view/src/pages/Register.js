import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { useAppContext } from "../context/appContext";
import { useNavigate } from "react-router-dom";
import bg from "../assets/loginbanner.jpg";
import Alert from "../components/Alert";

const Wrapper = styled.div`
  /* @import url("https://fonts.googleapis.com/css2?family=Passions+Conflict&display=swap"); */
  @import url(https://fonts.googleapis.com/css?family=Montserrat);

  box-sizing: border-box;
  /* font-family: Arial, Helvetica, sans-serif; */
  height: 100vh;
  /* Full-width input fields */
  input[type="text"],
  input[type="password"] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
  }

  input[type="text"]:focus,
  input[type="password"]:focus {
    outline-color: #00b4cc;
    color: #00b4cc;
  }
  input[type="checkbox"]:checked {
    accent-color: #00b4cc;
  }
  input[type="checkbox"]::before {
    background-color: #fff;
  }

  /* Set a style for all buttons */
  button {
    background-color: #00b4cc;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    border-radius: 50px;
  }

  button:hover {
    opacity: 0.8;
  }

  /* Center the image and position the close button */
  .imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
  }

  img.avatar {
    width: 40%;
    border-radius: 50%;
  }

  .container {
    padding: 16px;
    width: 250px;
    margin: 0 auto;
  }

  .rmfp {
    display: flex;
    justify-content: space-between;
  }

  span.psw {
    font-size: 11px;
  }

  span.psw a {
    color: #00b4cc;
    text-decoration: none;
  }

  /* The Modal (background) */
  .form {
    display: block;
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0, 0, 0); /* Fallback color */
    background-color: #00b4cc8c; /* Black w/ opacity */
    padding-top: 60px;
  }

  /* form Content/Box */
  .form-content {
    background-color: #fefefe;
    margin: 0 auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    /* width: 80%; Could be more or less, depending on screen size */
    width: 300px;
    border-radius: 10px;
    border-top: 5px solid #00b4cc;
  }

  /* The Close Button (x) */

  /* Add Zoom Animation */
  .animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s;
  }

  @-webkit-keyframes animatezoom {
    from {
      -webkit-transform: scale(0);
    }
    to {
      -webkit-transform: scale(1);
    }
  }

  @keyframes animatezoom {
    from {
      transform: scale(0);
    }
    to {
      transform: scale(1);
    }
  }

  /* Change styles for span and cancel button on extra small screens */
  @media screen and (max-width: 300px) {
    span.psw {
      display: block;
      float: none;
    }
    .cancelbtn {
      width: 100%;
    }
  }

  label {
    font-size: 13px;
    color: slategray;
  }

  .login-heading {
    text-align: center;
    font-size: 35px;
    margin: 0;
    padding: 50px 0;
    color: white;
    opacity: 0.8;
    z-index: 50;
    font-family: "montserrat", sans-serif;
  }
`;

const initialState = {
  username: "",
  // email: "",
  password: "",
  isMember: true,
};

const Register = () => {
  const [values, setValues] = useState(initialState);
  // gobal state and useNavigate
  const navigate = useNavigate();
  const { user, isLoading, showAlert, displayAlert, registerUser, loginUser } =
    useAppContext();
  const toggleMember = () => {
    setValues({ ...values, isMember: !values.isMember });
  };
  const handleChange = (e) => {
    e.preventDefault();
    setValues({ ...values, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const { username, email, password, isMember } = values;
    if (!password || (!isMember && !username)) {
      displayAlert();
      return;
    }
    const currentUser = { username, password };

    if (isMember) {
      loginUser(currentUser);
    } else {
      registerUser(currentUser);
    }
  };

  useEffect(() => {
    if (user) {
      setTimeout(() => {
        navigate("/");
      }, 2000);
    }
  }, [user, navigate]);
  return (
    <Wrapper
      id=""
      className="form"
      style={{ backgroundImage: "url(" + bg + ")" }}
    >
      <h2 className="login-heading">Points of Interest</h2>
      <form className="form-content animate" action="#" onSubmit={handleSubmit}>
        {showAlert && <Alert />}
        {/* <!-- <div className="imgcontainer">
          <span
            onclick="document.getElementById('id01').style.display='none'"
            className="close"
            title="Close form"
            >&times;</span
          >
          <img src="img_avatar2.png" alt="Avatar" className="avatar" />
        </div> --> */}

        <div className="container">
          <label htmlFor="username">Username</label>
          <input
            id="username"
            type="text"
            value={values.username}
            onChange={handleChange}
            name="username"
            required
          />

          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            value={values.password}
            onChange={handleChange}
            name="password"
            required
          />

          <button id="login-submit" type="submit">
            Login
          </button>
          <div className="rmfp">
            <label>
              <input type="checkbox" name="remember" />
              Remember me
            </label>

            <span className="psw">
              Forgot <a href="#">password?</a>
            </span>
          </div>
        </div>
      </form>
    </Wrapper>
  );
};

export default Register;
