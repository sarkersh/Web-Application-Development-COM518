import React from "react";
import { useAppContext } from "../context/appContext";
import styled from "styled-components";

const Wrapper = styled.div`
  @import url(https://fonts.googleapis.com/css?family=Montserrat);

  .alert {
    padding: 10px 0;
    width: 80%;
    margin: 5px auto;
    text-align: center;
    color: darkslategray;
    font-size: 13px;
    font-weight: 900;
    font-family: "montserrat", sans-serif;
    transition: ease-in-out 0.2s;
    border-radius: 10px;
  }

  .alert-danger {
    background-color: #cc000050;
    border-top: 3px solid #cc0000;
  }

  .alert-success {
    background-color: #28cc0050;
    border-top: 3px solid #28cc00;
  }

  .alert-warning {
    background-color: #00cc3350;
    border-top: 3px solid #00cc33;
  }
`;
const Alert = () => {
  const { alertType, alertText } = useAppContext();
  return (
    <Wrapper>
      <div className={`alert alert-${alertType}`}>{alertText}</div>
    </Wrapper>
  );
};

export default Alert;
