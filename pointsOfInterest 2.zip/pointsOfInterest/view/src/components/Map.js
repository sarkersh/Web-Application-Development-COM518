import React, { useEffect, useState } from "react";
import styled from "styled-components";
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  useMapEvents,
} from "react-leaflet";
import L from "leaflet";
import { useAppContext } from "../context/appContext";

const Wrapper = styled.div`
  box-sizing: border-box;
  /* overflow: hidden; */

  .leaflet-container {
    width: 80%;
    height: 50vh;
    display: flex;
    justify-content: end;
    margin: 30px auto;
  }
`;

function AddMarker({ saveMarkers }) {
  // create popup contents
  function hello() {
    alert("hello");
  }

  const customPopup = "working";

  // specify popup options
  const customOptions = {
    maxWidth: "400",
    width: "200",
    className: "popupCustom",
  };

  const map = useMapEvents({
    click: (e) => {
      const { lat, lng } = e.latlng;
      L.marker([lat, lng])
        .addTo(map)
        .bindPopup(customPopup, customOptions)
        .openPopup();
      saveMarkers([lat, lng]);
    },
  });
  return null;
}

function LocationMarker() {
  const [position, setPosition] = useState(null);
  const map = useMapEvents({
    click() {
      map.locate();
    },
    locationfound(e) {
      setPosition(e.latlng);
      map.flyTo(e.latlng, map.getZoom());
    },
  });

  return position === null ? null : (
    <Marker position={position}>
      <Popup>You are here</Popup>
    </Marker>
  );
}

const Map = () => {
  const [currentLocation, setCurrentLocation] = useState([]);
  const [position, setPosition] = useState(null);
  const { rows, totalRows, user } = useAppContext();
  const [marker, setMarker] = useState([[40.7, -74]]);
  const [data, setData] = useState([]);

  const saveMarkers = (newMarkerCoords) => {
    setData(newMarkerCoords);
    setMarker(data);
  };

  //   useEffect(() => {
  //     if (navigator.geolocation) {
  //       navigator.geolocation.getCurrentPosition(
  //         function (position) {
  //           setCurrentLocation(position.coords);
  //           console.log("Latitude is :", position.coords.latitude);
  //           console.log("Longitude is :", position.coords.longitude);
  //           console.log(currentLocation);
  //         },
  //         function (error) {
  //           console.error(error.message);
  //         }
  //       );
  //     } else {
  //       console.log("loading geolocation");
  //     }
  //   }, []);

  return (
    <Wrapper>
      <div id="poi-map">
        <MapContainer
          center={
            // currentLocation === []
            [37.779998779296875, -122.4000015258789]
            //   : [currentLocation.latitude, currentLocation.longitude]
          }
          zoom={13}
          scrollWheelZoom={false}
          // onClick={(mapEvent) => {
          //   console.log(mapEvent);
          // }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {rows.map((row) => (
            <Marker key={row.ID} position={[row.lat, row.lon]}>
              <Popup position={[row.lat, row.lon]}>
                <div>
                  <h3>{row.name}</h3>
                  <p>{row.description}</p>
                  <p>{row.recommendations} Peoples recomended</p>
                </div>
              </Popup>
            </Marker>
          ))}

          {/* {position === null ? null : (
            <Marker position={position}>
              <Popup>You are here</Popup>
            </Marker>
          )} */}
          <AddMarker saveMarkers={saveMarkers}>
            <Popup>You are here</Popup>
          </AddMarker>

          {/* <LocationMarker /> */}
        </MapContainer>
      </div>
    </Wrapper>
  );
};

export default Map;
